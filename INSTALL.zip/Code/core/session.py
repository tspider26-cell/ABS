class SessionManager:
    pass

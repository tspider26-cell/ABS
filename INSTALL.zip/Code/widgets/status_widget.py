class StatusWidget:
    pass

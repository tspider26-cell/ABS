class InfoPanel:
    pass
